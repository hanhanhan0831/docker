# 0.2.0-alpha
Change image to use updated phusion:baseimage and ubuntu 16:04

# 0.1.1
Security improvements to image.

# 0.1.0
Initial release - initial compatability with Concrete5.
